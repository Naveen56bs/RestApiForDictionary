package com.dictionary.model;

/**
 * 
 * This class would act as a bean which would take the input word to add/delete
 * to/from dictionary
 * 
 */
public class WordBean {
	private String word;

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}
}
